package jdbcbcexample;

import java.sql.DriverManager; //load or register the connector 
import java.sql.Connection; //establish the connection 
import java.sql.Statement;   //sql command execute  
import java.util.Scanner;
import java.sql.PreparedStatement; //create sql commands
import java.sql.ResultSet; // store sql result /output

public class DBConnectionExample {

	public static void saveData(int uid, String name, String email) {
		
		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/jdbccon","root","root");
			
			PreparedStatement ps = con.prepareStatement("insert into users(uid,name,emailid) values(?,?,?)");
			ps.setInt(1, uid);
			ps.setString(2, name);
			ps.setString(3, email);
			
			int r = ps.executeUpdate(); //insert, delete, udpate
			System.out.println(r+" rows inserted");
			
			
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println(e.toString());
			
		}
	}
	public static void getData() {
	
			try {
						
						Class.forName("com.mysql.jdbc.Driver");
						Connection con = DriverManager.getConnection("jdbc:mysql://localhost/jdbccon","root","root");
						
						Statement st = con.createStatement();
						
						ResultSet rs = st.executeQuery("select * from users");
						
						while(rs.next()) {
							System.out.println(rs.getString(1)+"\t"+rs.getString(2));							
						}
						
					
			}
			catch (Exception e) {
				System.out.println(e);
			}

	}
	
	public static void main(String[] args) {
		
	
		getData();
		Scanner sc = new Scanner(System.in);
		int uid;
		String name,email;
		System.out.println("enter eid, name, emaild ");
		uid = sc.nextInt();
		name = sc.next();
		email =sc.next();
		
		saveData(uid,name,email);
		
		getData();
		
	}

}
