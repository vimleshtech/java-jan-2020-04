package inhritence;

public class CurrentAccount extends BankAccount {

	String gstno;
	
	
	void newAccount(int acno, String name, int amt, String gst) {
		super.newAccount(acno, name, amt);
		this.gstno=gst;
		
	}
	void show() {
		super.show();
		System.out.println("gst no "+gstno);
		
		
	}
	
}
