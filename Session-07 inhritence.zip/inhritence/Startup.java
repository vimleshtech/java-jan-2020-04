package inhritence;

public class Startup {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SavingAccount sa =new SavingAccount();
		sa.newAccount(11, "niti", 5566,"fjfjf55","delhi");
		sa.show();
		
	}

}
