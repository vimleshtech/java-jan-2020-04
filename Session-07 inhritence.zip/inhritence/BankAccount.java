package inhritence;

public class BankAccount {

	int acno;
	String acname;
	int amt;
	
	void newAccount(int acno, String name, int amt) {
		this.acname = name;
		this.amt = amt;
		this.acno = acno;
		
	}
	void show() {
		System.out.println("acno is "+this.acno);
		System.out.println("acname is "+this.acname);
		System.out.println("amt is "+this.amt);		
	}
	
}
