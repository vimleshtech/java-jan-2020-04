package inhritence;

public class SavingAccount extends BankAccount {

	String panno;
	String address;
	
	void newAccount(int acno, String name, int amt, String panno, String address) {
		super.newAccount(acno, name, amt);
		this.panno =panno;
		this.address = address;
	}
	void show() {
		super.show();
		System.out.println("pan no "+panno);
		System.out.println("address is "+address);
		
	}
}
