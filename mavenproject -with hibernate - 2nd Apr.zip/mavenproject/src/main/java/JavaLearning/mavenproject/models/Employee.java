package JavaLearning.mavenproject.models;

public class Employee {

	private int eid;
	private String name;
	private String gender;
	
}
