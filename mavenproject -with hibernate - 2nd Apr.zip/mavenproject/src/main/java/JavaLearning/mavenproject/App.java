package JavaLearning.mavenproject;

/**
 * Hello world!
 *
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;


public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        
        try {
        	Class.forName("com.mysql.cj.jdbc.Driver");
        	Connection con = DriverManager.getConnection("jdbc:mysql://localhost/hrms","root","root");
        	Statement st = con.createStatement();
        	ResultSet rs =  st.executeQuery("select * from products");
        	
        	while(rs.next()) {
        		System.out.println(rs.getString(1)+"\t"+rs.getString(2));
        	}
        	
        }catch (Exception e) {
			// TODO: handle exception
        	e.printStackTrace();
		}
    }
}
