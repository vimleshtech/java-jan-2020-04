package exceptionexample;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class SaveDataToFile {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		//create new file if not exist, overwrite if exist 
		//FileWriter fw = new FileWriter("C:\\Users\\vkumar15\\Desktop\\out.txt");
		
		//append  : true
		FileWriter fw = new FileWriter("C:\\Users\\vkumar15\\Desktop\\out.txt",true);
		
		BufferedWriter bw = new BufferedWriter(fw);
		bw.write("hello ");
		bw.newLine();
		bw.write("bye ");
		bw.close();
		fw.close();
		System.out.println("data file is saved");
		
	}

}
