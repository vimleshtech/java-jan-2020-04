package exceptionexample;

import java.util.Scanner;

public class ExceptionExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int n,d,o;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter num ");
		n = sc.nextInt();
		
		System.out.println("enter num ");
		d = sc.nextInt();
		
		//div
		try {
			
			if(d<0) {
				ArithmeticException ex = new ArithmeticException("divisor cannot be less than 0");
				throw ex; //throw is just line go to statement
			}
			o = n/d;
			System.out.println("div "+o);
		}
		catch(ArithmeticException ex) {
			System.out.println(ex);
			//ex.printStackTrace();
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println(e);
		}
		catch (Exception er) {
			// TODO: handle exception
			//System.out.println(er);
			System.out.println("invalid data ");
		}
		finally {
			System.out.println("end of block");
		}
		//add
		o = n+d;
		System.out.println("\nsum of two values "+o);

	}

}
