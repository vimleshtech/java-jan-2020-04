package collectionexample;

import java.util.HashMap;

public class MapExample {

	public static void main(String[] args) {

		
		HashMap m = new HashMap();
		m.put(1, "alpha");
		m.put(2, "delta");
		m.put("t", 100);
		
		
		System.out.println(m.size());
		System.out.println(m.get("t"));
		System.out.println(m.get(2));
		
		
		//
		HashMap<String, String> s = new HashMap();
		//HashMap<String, String> s = new HashMap<>();
		//HashMap<String, String> s = new HashMap<String,String>();
		
		s.put("a", "test");
		
		
	}

}
