package collectionexample;

import java.util.Set;
import java.util.TreeSet;

public class SetExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Set s = new TreeSet();
		s.add(11);
		s.add(11);
		s.add(113);
		s.add(11);
		s.add(1144);
		System.out.println(s);
		
	}

}
