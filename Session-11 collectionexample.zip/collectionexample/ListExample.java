package collectionexample;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ListExample {

	public static void main(String[] args) {

		List l = new ArrayList();
		//or
		ArrayList a = new ArrayList(); //dynamic size and data type 
		
		a.add(11);
		a.add(121);
		a.add("test data");
		a.add(true);
		a.add(11.444);
		a.add(1221);
		
		//get length
		System.out.println(a.size()); //get length 
		
		//print data 
		System.out.println(a.get(1));
		
		//remove data
		a.remove(0);
		System.out.println(a.size()); 
		
		//iterate 
		for(int i=0; i<a.size();i++) {
			System.out.println(a.get(i));
		}
		
		//or
		Iterator it  = a.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		
		
		//generic 
		ArrayList<String> s = new ArrayList<>();
		s.add("nitin");
		s.add("fjkfgf");
		s.add("fkjfhg");
		s.add("gjkfgghd");
		s.add("fkjfgddfg");
		s.add("fkjfgghf4");
		
		System.out.println(s.size());
		
	}

}
