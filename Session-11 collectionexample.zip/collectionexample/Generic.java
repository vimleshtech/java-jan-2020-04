package collectionexample;

import java.util.ArrayList;

class Employee{
	
	int eid;
	String name;
	int sal;
	
	Employee(int eid, String name, int sal){
		this.eid =eid;
		this.name =name;
		this.sal = sal;
	}
}

public class Generic {

	public static void main(String[] args) {

		ArrayList<Employee> e = new ArrayList<>();
		
		Employee ee =new Employee(11, "nitin", 555);
		e.add(ee);
		
		e.add(new Employee(33, "rahul", 55666));
		e.add(new Employee(133, "6rahul", 155666));
		e.add(new Employee(233, "5rahul", 255666));
		e.add(new Employee(333, "4rahul", 355666));
		e.add(new Employee(433, "2rahul", 455666));
		e.add(new Employee(533, "1rahul", 55666));
		e.add(new Employee(633, "rahul", 55666));
		
		
		System.out.println(e);
		System.out.println(e.get(0));
		System.out.println(e.size());
		
		
		for(int i=0;i<e.size();i++) {
			
			System.out.println(e.get(i).eid+"\t"+e.get(i).name+""+e.get(i).sal);
		}
		
		

	}

}
