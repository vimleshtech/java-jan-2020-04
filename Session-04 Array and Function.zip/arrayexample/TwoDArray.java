package arrayexample;

import java.util.Scanner;

public class TwoDArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		 * 00 01 02
		 * 10 11 12
		 */
		String x[][]= {{"Nitin","Delhi","Male"},
						{"Monika","Delhi","Female"}};
		System.out.println(x.length); //get row length
		
		System.out.println(x[0].length); //get col length 
		System.out.println(x[0][1]); //print 2nd value of 1st row 
		
		Scanner sc = new Scanner(System.in);
		//Dynamic
		int y[][]= new int[3][4];
		System.out.println("enter data ");
		for(int i=0;i<3;i++) {
			for(int j=0;j<4;j++) {
		
				y[i][j] = sc.nextInt();
			}
		}
		//print
		for(int d[] : y) {//row <- table 
			for(int data : d) {  //cell/col <- row 
				System.out.print(data);
			}
			System.out.println();
		}
		
	}

}
