package arrayexample;

import java.util.Scanner;

import org.omg.Messaging.SYNC_WITH_TRANSPORT;

public class ArrayExample {

	public static void main(String[] args) {

		//declare array
		int n[] = new int[3];
		n[0] =1;
		n[1] =133;
		n[2] =144;
		
		System.out.println(n.length); //print size
		System.out.println(n); //print memrory adddress
		System.out.println(n[1]); //print 2nd value 
		//read all data 
		for(int i=0; i<n.length;i++) {
			System.out.println(n[i]);
		}
		
		//or
		for(int x:n) {
			System.out.println(x);
		}
		
				
		///or another way
		int y[]= {44,556,66,33};
		System.out.println(y.length);
		System.out.println(y[0]);

		
		//dynamic input
		int size;
		Scanner sc = new Scanner(System.in);
		System.out.println("enter size of array ");
		size = sc.nextInt();
		
		int data[] = new int[size];
		for(int i=0; i<size;i++) {
			System.out.println("enter data ");
			data[i] = sc.nextInt();
		}
		
		for(int x: data) {
			System.out.println(x);
		}
	}

}
