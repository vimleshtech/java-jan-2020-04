package functionexample;

import java.util.Scanner;

public class FunctionExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		welcome();
		welcome();
		
		int o1 = getData();
		int o2 = getData();
		System.out.println(o1+o2);
		System.out.println(o1);
		
		add(11,334);
		add(55,66);
		
		int oo = sub(44,5);
		System.out.println(oo);
	}
	
	static void welcome() {
		System.out.println("welcome to function world...this class contains main,welcome ,getdata,add, sub");
	}

	static int getData() {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter data ");
		int n = sc.nextInt();
		
		//char c = sc.next().toCharArray()[0];
		
		return n;
	}
	
	static void add(int a, int b) {
		int c =a+b;
		System.out.println(c);
	}
	
	static int sub(int a, int b) {
		int c =a-b;
		return c;
	}
	
	static int fact(int c) {
		
		if(c==1) {
			return c;
		}else {
			return c*fact(c-1);
		}
	}
}
