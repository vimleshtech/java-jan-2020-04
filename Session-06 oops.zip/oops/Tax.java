package oops;

public class Tax {

	private String country;
	private int amt;
	
	//default 
	Tax(){
		System.out.println("in default constructor");
	}
	//with paramter 
	Tax(String country){
		System.out.println("in pramater "+country);
		this.country = country;
	}
	//with prameter oveloading 
	Tax(String country, int amt){
		
		System.out.println("in parameterize "+country+"\t"+amt);
		this.amt = amt;
		this.country = country;		
	}	
	//copy constructor
	Tax(Tax t){
		
		System.out.println("in copy constructor "+t);
		this.amt = t.amt;  //copy data from previous object to new object 
		country = t.country; //copy data from previous object to new object 
		System.out.println(this.amt);
		System.out.println(this.country);
		
	}
	
	void gst() {
		
		System.out.println(amt);
		System.out.println(country);
		
		double tax_amt=0;
		if(this.country.equals("india")) {
			tax_amt = amt*.18;
		}
		else if(this.country.equals("us")) {
			tax_amt = amt*.28;
		}
		else {
			tax_amt = amt*.30;
		}
		System.out.println("tax amout is "+tax_amt);
	}
}
