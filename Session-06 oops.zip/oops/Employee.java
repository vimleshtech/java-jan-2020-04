package oops;

import java.util.Scanner;

//Employee class
public class Employee {

	//data member s
	private int eid;
	private String ename;
	private int sal;
	
	//methods 
	void newEmployee() {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter eid, name , and sal ");
		eid =sc.nextInt();
		ename = sc.next();
		sal = sc.nextInt();
		
	}
	void show() {
		
		System.out.println("----employee details ----");
		System.out.println("eid:"+eid+" ename:"+ename+" sal:"+sal);
	}
	
	
}
