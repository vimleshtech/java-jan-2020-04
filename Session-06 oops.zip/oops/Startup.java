package oops;

public class Startup {

	public static void main(String[] args) {
		
		/*
		Employee e = new Employee();//here e is an object of class Employoeem
									//new is keyword which allocates the memory 
									//Employee() is constructor 
		e.newEmployee(); //invoke to function 
		e.show(); //invoke to function 
		*/
		
		//object of Tax class
		Tax t1 = new Tax();
		Tax t2 = new Tax("India");
		Tax t3 = new Tax("US",100);		
		Tax t4 = new Tax(t3);//copy constructor 
				
		t3.gst();
		t4.gst();
		t2.gst();
		//t1.gst(); //error
		
	}

}
