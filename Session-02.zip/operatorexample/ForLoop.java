package operatorexample;

public class ForLoop {

	public static void main(String[] args) {

		//for loop
		for(int i=1;i<10;i++) {
			System.out.println(i);	
		}
		
		//in reverse 
		for(int i=10;i>0;i++) {
			
			System.out.println(i);	
		}
		
		

	}

}
