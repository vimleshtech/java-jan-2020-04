package operatorexample;

import java.util.Scanner;

public class Ifcconditon {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double salesamt;
		double tax=0,total=0;
		
		Scanner sc = new Scanner(System.in);		
		//take input from user
		System.out.println("etner sales amt ");
		salesamt =sc.nextDouble();

		if(salesamt>1000) 
			tax = salesamt*.18; //18 % tax on salesamt
		
		
		total = salesamt+tax;
		System.out.println("you have to pay "+total);
		
	}

}
