package operatorexample;

import java.util.Scanner;

public class NestedIfElse {

	public static void main(String[] args) {		
		//WAP to show greater number from three input
		Scanner s = new Scanner(System.in);
		int a,b,c;
		
		System.out.println("enter  num for a , b , c");
		a = s.nextInt();
		b = s.nextInt();
		c = s.nextInt();
		
		if(a>b) {
			
				if(a>c) {
						System.out.println("a is greater");
				}
				else {
						System.out.println("c is greater");
				}
		}
		else {
			
			if(b>c) {
					System.out.println("b is greater");
			}else {
				System.out.println("c is greater ");
			}
		}
		
		//and conditon 
		//multiple condition
		if(a>b && a>c) {
			System.out.println("a is greater");
		}else if(b>a && b>c) {
			System.out.println("b is greater");
		}else {
			System.out.println("c is greater ");
		}
		
	}

}
