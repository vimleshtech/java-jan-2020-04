package operatorexample;

import java.util.Scanner;

public class WhileExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int i=1; //init
		while(i<10) { //condition 
			//System.out.println(i); //ln - new line 
			System.out.print(i); //print in same line 
			i++; //increment
		}
		
		//print in reverse 
		i =10;
		while(i>0) {
			System.out.println(i);
			i--;
		}
		
		//print table of given num
		Scanner sc = new Scanner(System.in);
		int n;
		System.out.println("enter num");
		n = sc.nextInt();
		
		i=1;
		while(i<=10) {
			System.out.println(n*i);
			i++;
		}
		
		
		//wap to get sum of all even and odd numebrs between two given range 
		
		int se=0,so=0;
		int n1,n2;
		System.out.println("enter start and end num");
		n1= sc.nextInt();
		n2 = sc.nextInt();
		
		while(n1<=n2) {
			
			if(n1%2 ==0) {
				se+=n1;
			}else {
				so+=n1;
			}
			n1++;
		}
		
		System.out.println("sum of all even "+se);
		System.out.println("sum of all odd "+so);
	}

}
