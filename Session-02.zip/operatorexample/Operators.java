package operatorexample;

public class Operators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
				int i,j;
				i =0;
				j=0;
				
				System.out.println(i++); //0
				System.out.println(++j); //1
				
				System.out.println(i); //1
				System.out.println(j); //1
				
				i=1;
				System.out.println((i++)+1); //2
				i=1;
				System.out.println((++i)+1); //2
				
	}

}
