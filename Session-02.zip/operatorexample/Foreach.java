package operatorexample;

public class Foreach {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Foreach : is called advance loop
		// is forward only 
		// works with or for collection or array 
		
		int n[] = {11,343,556,23233,5};
		
		int s=0;
		for(int x: n) { //: assigen value from right to left one by one
			System.out.println(x);
			s+=x;
		}
		System.out.println(s);
	}

}
