package operatorexample;

import java.util.Scanner;

public class SwitchCase {

	public static void main(String[] args) {
		//switch case: for exact match 
		
		Scanner s = new Scanner(System.in);
		int key;
		System.out.println("press \n 1 for add \n 2 sub \n 3 of mul ... ");
		key = s.nextInt();
		
		switch (key) {
		case 1:
			System.out.println("a+b");
			break;
		case 2:
			System.out.println("a-b");
			break;
		case 3:
			System.out.println("a*b");
			break;
		default:
			System.out.println("not match");
			break;
		}

		
	}

}
