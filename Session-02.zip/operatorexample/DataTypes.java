package operatorexample;

public class DataTypes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		byte b =21;
		short s =5454;
		int i =545654342;
		long l = 5435555543556666l;
		
		System.out.println(b);
		System.out.println(s);
		System.out.println(i);
		System.out.println(l);
		
		//
		float f=5444.444f;
		System.out.println(f);
		
		double d = 5.565445445654444455d;
		System.out.println(d);
		
		
		
		
		
		
	}

}
