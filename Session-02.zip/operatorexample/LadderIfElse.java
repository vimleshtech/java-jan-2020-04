package operatorexample;

import java.util.Scanner;

public class LadderIfElse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		double salesamt;
		double tax=0,total=0;
		
		Scanner sc = new Scanner(System.in);		
		//take input from user
		System.out.println("etner sales amt ");
		salesamt =sc.nextDouble();

		if(salesamt>1000) 
			tax = salesamt*.18; //18 % tax on salesamt		
		else if(salesamt>500)
			tax = salesamt*.12;
		else if(salesamt>200)
			tax = salesamt*.10;
		else
			tax = salesamt*.05;
		
		total = salesamt+tax;
		System.out.println("you have to pay "+total);

		
	}

}
