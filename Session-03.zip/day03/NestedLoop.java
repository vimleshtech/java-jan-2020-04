package day03;

public class NestedLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for(int i=1; i<=3; i++) {
			for(int j=1; j<=3; j++) {
				System.out.println(j);
			}	
		}
		//print in same line
		for(int i=1; i<=3; i++) {
			for(int j=1; j<=3; j++) {
				System.out.print(j);
			}	
		}
		System.out.println();
		//show in matrix format 
		for(int i=1; i<=3; i++) {
			for(int j=1; j<=3; j++) {
				System.out.print(j);
			}	
			System.out.println();
		}
		
		//
		System.out.println();
		//show in matrix format 
		for(int i=1; i<=5; i++) {
			for(int j=1; j<=i; j++) {
				System.out.print(j);
			}	
			System.out.println();
		}
		//
		System.out.println();
		//show in matrix format 
		for(int i=1; i<=5; i++) {
			for(int j=1; j<=6-i; j++) {
				System.out.print(j);
			}	
			System.out.println();
		}
		
	}

}
