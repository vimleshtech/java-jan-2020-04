package day03;

public class B76A {

	public static void main(String[] args) {
		
		for(int i=1; i<=80; i=i*2) {
			
			System.out.println(i);
			
		}
		
		
		//
		for(int i=1; i<=80; i=i+3) {
			
			if(i%2==0)
				System.out.print(i*-1+",");
			else
				System.out.print(i+",");
			
		}
		


	}

}
