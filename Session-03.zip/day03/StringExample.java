package day03;

import java.net.SocketTimeoutException;
import java.util.Scanner;

public class StringExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		String name;
		System.out.println("entrer name  ..");
		name = sc.nextLine(); //read complete line
		
		//
		String s = name.toUpperCase();
		System.out.println(s);
		System.out.println(name.toLowerCase());
		System.out.println(name.length());
		System.out.println(name.replace("a", "xy"));
		
		
		int ps = name.indexOf("m");
		System.out.println(ps);
		
		char c = name.charAt(2);
		System.out.println(c);
		
		//convert to ascii 
		int as = 'a';
		System.out.println(as); 
		
		
		//substring 
		String st = name.substring(2,5); //2 to 4
		System.out.println(st);
		
		//
		String ss = name.concat("kumar");
		System.out.println(ss);
		
		
		//
		String words[]= name.split(" ");
		System.out.println(words);//print address of object
		System.out.println(words.length);//length of array 
		System.out.println(words[0]);
		System.out.println(words[1]);
	
		//itearator 
		for(String w:words) {
			System.out.println(w);
		}
		
		
		//break by char
		char cc[] = name.toCharArray();
		
		//
		System.out.println(name.trim());
		
		
		///
		if(name.contains("ma")) {
			System.out.println("ma is presnet ");
		}
		//
		if(name.startsWith("r")) {
			System.out.println("start with r");
		}
		
		//
		if(name.endsWith("n")) {
			System.out.println("end with n");
		}
		//
		if(name.equals("raman sinha")) {
			System.out.println("match ");
		}
		
		//
		if(name.equalsIgnoreCase("RAman SINHa")) {
			System.out.println("raman sinha match");
		}
		
	}

}
