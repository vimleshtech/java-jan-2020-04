package day03;

public class BreakAndContinue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//break
		for(int i=1; i<10;i++) {
			
			if(i%4==0)
				break;
			
			System.out.println(i);
			
		}
		
		//contiue
		for(int i=1; i<10;i++) {
			
			if(i%4==0)
				continue;
			
			System.out.println(i);
			
		}
	}

}
