package abstractclass;

public class Caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//AbsExample o = new AbsExample(); //not allowed
		
		Imps o = new Imps();
		o.add(11, 3);
		o.sub(33, 5);
		o.mul(2, 4);
		
	}

}
