package abstractclass;

public class Imps extends AbsExample {

	@Override
	void sub(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println(a-b);
	}

	@Override
	void mul(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println(a*b);
	}

	
}
