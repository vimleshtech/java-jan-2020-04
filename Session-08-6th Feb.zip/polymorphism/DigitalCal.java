package polymorphism;

public class DigitalCal extends Cal {

	void welcome() {
		System.out.println("in child class");
	}
	
	void mul(int a, int b) {
		System.out.println(a*b);
	}
	void add(int a, int b, int c, int d) {
		System.out.println(a+b+c+d);
	}
}
