package polymorphism;

public class Caller {

	public static void main(String[] args) {
		
		DigitalCal d = new DigitalCal();
		d.add(11.22, 44.5);
		d.add(11, 223);
		d.add(111, 233,44,55);
		d.add(11, 223,22);
		d.mul(11, 33);
		
		//
		Cal c = new Cal();
		c.welcome();
		
		DigitalCal dd = new DigitalCal();
		dd.welcome();
		
		//overriding 
		c = dd;
		
		c.welcome(); //child 
		//or
		Cal co = new DigitalCal();
		co.welcome();
		
		
		
		
	}

}
