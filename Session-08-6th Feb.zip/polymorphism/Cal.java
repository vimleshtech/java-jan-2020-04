package polymorphism;

public class Cal {

	void welcome() {
		System.out.println("in parent class");
	}
	void add(int a, int b) {
		
		System.out.println("sum of two numbers "+(a+b));
		
	}	
	void add(int a, int b, int c) {
		System.out.println("sum of tree numbers "+(a+b+c));
	}
	void add(double a, double b) {
		System.out.println("sum of double "+(a+b));
	}
}
