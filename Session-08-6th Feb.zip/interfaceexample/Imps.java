package interfaceexample;

public class Imps implements Ia,Ib {

	@Override
	public void add(int a, int b) {
		// TODO Auto-generated method stub
		
		System.out.println(a+b);
	}

	@Override
	public void sub() {
		// TODO Auto-generated method stub
		System.out.println("sub");
	}

}
