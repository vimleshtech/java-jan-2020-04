package interfaceexample;

public class Caller {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

		Imps a = new Imps();
		a.sub();
		a.add(1, 3);
		
		
		Ib d = new Imps();
		d.add(11, 3);
		
		
	}

}
