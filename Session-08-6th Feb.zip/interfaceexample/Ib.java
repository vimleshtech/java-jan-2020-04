package interfaceexample;

public interface Ib {

	void add(int a, int b);
	void sub();
	
}
