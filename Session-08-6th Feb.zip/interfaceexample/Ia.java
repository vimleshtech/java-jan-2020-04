package interfaceexample;

public interface Ia {

}
